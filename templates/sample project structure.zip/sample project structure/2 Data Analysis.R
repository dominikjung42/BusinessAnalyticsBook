#' chapter 2 - Business Analytics Toolbox
#' contact: Dominik Jung, dominikjung42@gmail.com

# libraries ---------------------------------------------------------------
library("dplyr")
library("ggplot2")
library("readxl")
library("dstools")


# business data understanding ---------------------------------------------
dataset <- read_excel("whiskyproductionlog.xlsx")
# or just run data("whisky_collection")
View(whisky_collection)

str(whisky_collection)

# example -----------------------------------------------------------------

# 1. possibility
my_vector = c(10, 20, 30, 40, 50, 60, 70, 80, 90, 100)

# 2. possibility
my_vector = c(seq(10, 100, by=10))
my_vector

names(my_vector) = c("Holger", "Samantha", "Bernd", "Anna", "Fred", "Nicky", "Louis", "Jennifer", "Jack", "Zoe")
my_vector
my_vector["Zoe"]
my_vector[c("Zoe")]



my_matrix <- matrix(1:9, nrow = 3)
my_matrix








