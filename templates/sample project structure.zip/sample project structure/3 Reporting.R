#' chapter 3 - Business Data
#' contact: Dominik Jung, dominikjung42@gmail.com

# libraries ---------------------------------------------------------------
library("dplyr")
library("ggplot2")
library("readxl")



# Webdata -----------------------------------------------------------------
install.packages("readr", dependencies = TRUE)
library (readr)

# Read from the web
urlfile="https://github.com/dominikjung42/BusinessAnalyticsBook/tree/main/data/whiskycollection.csv"
dataset <- read_csv(url(urlfile))

# Download it and read the file locally
download.file(urlfile, destfile="./whiskycollection2.csv")
dataset <- read_csv("whiskycollection.csv")

# Generate a new csv
#write.table(whisky_collection, file = "whiskycollection.csv", sep=",")


# webdata - scraping ------------------------------------------------------
install.packages("rvest", dependencies = TRUE)
library(rvest)

# Specify the url for desired website to be scraped
url <- "https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population"
url <- "https://en.wikipedia.org/wiki/List_of_whisky_distilleries_in_Scotland"
population <- read_html(url)
population <- html_nodes(population, "table.wikitable")
table <- html_table(table, header = TRUE)
print(table)




#CReate SQL Lite dataset
my_db <- src_sqlite(my_db_file, create = TRUE)



# sclaing and rescaling ---------------------------------------------------
library(readxl)
whisky_collection <- read_excel("whiskycollection.xlsx")
head(whisky_collection)


# split-aply-combine ------------------------------------------------------
library(dplyr)

filter(whisky_collection, LOCATION == "Scotland")

filter(whisky_collection, LOCATION %in% c("Scotland", "USA"))

filter(whisky_collection, LOCATION == "Scotland" | (LOCATION == "USA" & TYPE == "Single Malt"))


subset_scotland = filter(whisky_collection, LOCATION == "Scotland")
subset_scotland_red = select(subset_scotland, NAME, RATING)
subset_scotland_red_final = filter(subset_scotland_red, RATING >= 4)

whisky_collection %>% 
  filter(LOCATION == "Scotland") %>% 
  select(NAME, RATING) %>% 
  filter(RATING >= 4)

whisky_collection_new = whisky_collection %>% 
  filter(LOCATION == "Scotland") %>% 
  select(NAME, RATING) %>% 
  filter(RATING >= 4) %>% 
  mutate(FAVOURITE = 1)

whisky_collection_new = whisky_collection %>% 
  mutate(AGE = 2023 - FOUNDATION)

whisky_collection_new = whisky_collection %>% 
  mutate(FAVORITE = ifelse(LOCATION == "Scotland", TRUE,
                            ifelse(RATING >= 4, TRUE, FALSE)))

whisky_collection_new = whisky_collection %>%
  group_by(LOCATION) %>% 
  mutate(BENCHMARK = mean(RATING))

whisky_collection_new = whisky_collection %>%
  group_by(LOCATION) %>% 
  summarize(BENCHMARK = mean(RATING))

whisky_collection_new = whisky_collection %>%
  group_by(LOCATION) %>%
  summarize(BENCHMARK = mean(RATING), NUM = n())


# Loading data ------------------------------------------------------------
library(dstools)
#library(devtools)
#install_github("dominikjung42/dstools")


# clean data names --------------------------------------------------------------
whisky_collection_new <- make_names(whisky_collection)
head(whisky_collection_new)

# do not use, deprecated
#whisky_collection_new <- make.names(whisky_collection)
#head(whisky_collection_new)


# long to wide ------------------------------------------------------------
library(dplyr)
library(tidyr)
library(readxl)

whisky_collection <- read_excel("whiskycollection.xlsx")
#whisky_collection <- make_names(whisky_collection)

head(whisky_collection)

whisky_ratings <- whisky_collection %>%
  filter(TYPE %in% c("Single Malt", "Blended")) %>% 
  group_by(LOCATION, TYPE) %>%
  summarize(MEAN_RATING = mean(RATING))

head(whisky_ratings)

# Pivoting from long to wide format
whisky_ratings_long <- whisky_ratings %>%
  pivot_wider(names_from = TYPE, values_from = MEAN_RATING)

whisky_ratings_wide <- whisky_ratings %>%
  pivot_wider(names_from = TYPE, values_from = MEAN_RATING)





# sclaing and rescaling bonusaufgabe ---------------------------------------------------
library(readxl)
whisky_collection <- read_excel("whiskycollection.xlsx")
head(whisky_collection)

# Euclidian distance
p <- c(63, 150) 
q <- c(67, 160) 
sqrt((p[1]-q[1])^2 + (p[2]-q[2])^2)
dist(rbind(p,q), method="euclidian")

# rescaling
whiskycollection
selection <- cbind(whiskycollection$Height_us, whiskycollection$Weight)
dist(selection, method="euclidian")

selection <- cbind(whiskycollection$Height_world, whiskycollection$Weight)
dist(selection, method="euclidian")
  
  