#' chapter 1 - Introduction
#' contact: Dominik Jung, dominikjung42@gmail.com

# libraries ---------------------------------------------------------------
install.packages("dplyr")
install.packages("ggplot2")
install.packages("readxl")

library("dplyr")
library("ggplot2")
library("readxl")

# business data understanding ---------------------------------------------
dataset <- read_excel("productionlog_sample.xlsx")
# or just run dataset <- data("productionlog_sample") if dstools is installed
head(dataset)

View(dataset)

summary(dataset)

# business data preprocessing ---------------------------------------------

# dataset <- dataset[c(),]
dataset <- na.omit(dataset)

# business analytics ------------------------------------------------------
plot(x=dataset$COLOR, y=dataset$TASTING)

plot(x=dataset$MALTING, y=dataset$TASTING)

boxplot(TASTING ~ SHIFT, data = dataset)
boxplot(TASTING ~ MALTING, data = dataset)
boxplot(TASTING ~ MANUFACTURER, data = dataset)

dataset_subset <- subset(dataset, MALTING==c("Burns Best Ltd."))
mean(dataset_subset$TASTING)

dataset_subset <- subset(dataset, MALTING==c("Inhouse"))
mean(dataset_subset$TASTING)


